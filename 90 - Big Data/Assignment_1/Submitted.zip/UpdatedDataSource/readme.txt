public repository: https://hub.docker.com/r/leobcc/big_data_weather_assignment

Person 1: Leonardo Bocchi
Email: lbocchbo37@alumnes.ub.edu

Person 2: Jordi Segura Pons
Email: jsegurpo8@alumnes.ub.edu