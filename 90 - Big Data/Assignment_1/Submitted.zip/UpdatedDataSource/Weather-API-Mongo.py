#!/usr/bin/env python
# coding: utf-8

import pandas as pd
import http.client
import datetime
import pymongo

conn = http.client.HTTPSConnection("weatherapi-com.p.rapidapi.com")

headers = {
    'X-RapidAPI-Key': "ba328159ecmsh31f65206c5ab959p1a3f80jsnb80160476df3",
    'X-RapidAPI-Host': "weatherapi-com.p.rapidapi.com"
    }

def api_get(x):
    """Calls the API with the x being the column, in our case the ZIP, as the query.

    Args:
        x (int): ZIP code

    Returns:
        dict: A dictionary with the results
    """
    conn.request("GET", f"/current.json?q={x}", headers=headers)
    response = conn.getresponse()
    return response.read().decode('utf-8')

# Parse the CSV and store the zip code and city name in a collection called city_weather
top100_df = pd.read_csv('Top100-US.csv', sep=';')
top100_dict = top100_df.to_dict("records")

client = pymongo.MongoClient("mongodb")
db = client["city_weather"]
collection = db["weather_data"]


for row in top100_dict:
    row['created_at'] = datetime.datetime.now()
    row['weather'] = api_get(row["Zip"])

result = collection.insert_many(top100_dict)

print(result)


